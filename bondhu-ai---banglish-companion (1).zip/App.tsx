
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Message, AppMode, AppState } from './types';
import { WELCOME_MESSAGE } from './constants';
import { chatWithGemini, generateImage, analyzeImage } from './services/gemini';
import Sidebar from './components/Sidebar';
import ChatBubble from './components/ChatBubble';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      text: WELCOME_MESSAGE,
      timestamp: new Date(),
      type: 'text'
    }
  ]);
  const [mode, setMode] = useState<AppMode>(AppMode.CHAT);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setMode(AppMode.VISION);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!inputText.trim() && !selectedImage) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: inputText,
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputText;
    setInputText('');
    setIsTyping(true);

    try {
      if (mode === AppMode.CHAT) {
        const history = messages
          .filter(m => m.type === 'text')
          .slice(-6)
          .map(m => ({
            role: m.role,
            parts: [{ text: m.text }]
          }));
        
        const response = await chatWithGemini(currentInput, history);
        
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'model',
          text: response.text,
          timestamp: new Date(),
          type: 'text',
          groundingUrls: response.groundingUrls
        }]);
      } 
      else if (mode === AppMode.IMAGE) {
        const imageUrl = await generateImage(currentInput);
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'model',
          text: `Ai je boss, apnar chobi ready: "${currentInput}"`,
          timestamp: new Date(),
          type: 'image',
          imageUrl
        }]);
      }
      else if (mode === AppMode.VISION && selectedImage) {
        const result = await analyzeImage(selectedImage, currentInput || "Describe this image in Banglish.");
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'model',
          text: result || "Image ta bujhte parini boss.",
          timestamp: new Date(),
          type: 'text'
        }]);
        setSelectedImage(null);
      }
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: "Opps! Kichu ekta problem hoyeche. Network check korun ba abar try korun. Sorry for the trouble! 🙏",
        timestamp: new Date(),
        type: 'text'
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-screen bg-slate-950 text-slate-100">
      <Sidebar currentMode={mode} setMode={setMode} />
      
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-slate-900/50 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${isTyping ? 'bg-green-500 animate-pulse' : 'bg-slate-600'}`}></div>
            <h2 className="font-semibold text-sm tracking-wide">
              {mode === AppMode.CHAT && "Bondhu is Listening..."}
              {mode === AppMode.IMAGE && "Generating Art Vibes"}
              {mode === AppMode.VISION && "Analyzing Visuals"}
            </h2>
          </div>
          <div className="flex items-center gap-4 text-xs font-medium text-slate-400">
             <span className="hidden sm:inline">Banglish Mode Active 🇧🇩🇬🇧</span>
          </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-2">
          <div className="max-w-4xl mx-auto">
            {messages.map((msg) => (
              <ChatBubble key={msg.id} message={msg} />
            ))}
            
            {isTyping && (
              <div className="flex justify-start mb-4">
                <div className="bg-slate-800 rounded-2xl p-4 flex gap-1">
                  <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce"></div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input Area */}
        <div className="p-4 bg-gradient-to-t from-slate-950 via-slate-950 to-transparent">
          <div className="max-w-4xl mx-auto">
            {selectedImage && (
              <div className="mb-4 relative inline-block animate-in zoom-in-95 duration-200">
                <img src={selectedImage} alt="Preview" className="h-32 rounded-lg border-2 border-blue-500" />
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center shadow-lg"
                >
                  ✕
                </button>
              </div>
            )}
            
            <div className="relative bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl focus-within:border-blue-500 transition-all duration-300">
              <div className="flex items-end p-2">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="p-3 text-slate-400 hover:text-blue-400 transition-colors"
                  title="Photo share korun"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={handleImageUpload}
                />
                
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder={
                    mode === AppMode.CHAT ? "Ajke ki bolte chan? Message likhun..." :
                    mode === AppMode.IMAGE ? "Ki chobi banate chan? Type korun..." :
                    "Photo nie kichu jigges korun..."
                  }
                  className="flex-1 bg-transparent border-none focus:ring-0 text-slate-100 p-3 max-h-32 min-h-[48px] resize-none bengali-text"
                  rows={1}
                />

                <button
                  onClick={handleSend}
                  disabled={isTyping || (!inputText.trim() && !selectedImage)}
                  className={`p-3 rounded-xl transition-all duration-200 ${
                    isTyping || (!inputText.trim() && !selectedImage)
                    ? 'bg-slate-800 text-slate-600'
                    : 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-900/20 active:scale-95'
                  }`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                </button>
              </div>
            </div>
            
            <p className="text-[10px] text-center text-slate-500 mt-3 bengali-text">
              Bondhu AI bhul korte pare, so cross-check kore nio boss. Made with ❤️ in Banglish.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;

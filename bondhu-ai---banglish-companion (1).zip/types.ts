
export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  type: 'text' | 'image';
  imageUrl?: string;
  groundingUrls?: Array<{ uri: string; title: string }>;
}

export enum AppMode {
  CHAT = 'CHAT',
  IMAGE = 'IMAGE',
  VISION = 'VISION'
}

export interface AppState {
  messages: Message[];
  isTyping: boolean;
  mode: AppMode;
}

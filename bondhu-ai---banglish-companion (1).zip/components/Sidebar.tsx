
import React from 'react';
import { AppMode } from '../types';

interface SidebarProps {
  currentMode: AppMode;
  setMode: (mode: AppMode) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentMode, setMode }) => {
  const menuItems = [
    { id: AppMode.CHAT, icon: '💬', label: 'Bondhu Chat', desc: 'Just talk in Banglish' },
    { id: AppMode.IMAGE, icon: '🎨', label: 'Chobi Banai', desc: 'Create AI Art' },
    { id: AppMode.VISION, icon: '👁️', label: 'Dekho To', desc: 'Analyze images' },
  ];

  return (
    <div className="w-full md:w-64 bg-slate-900 border-r border-slate-800 flex flex-col p-4">
      <div className="flex items-center gap-3 mb-8 px-2">
        <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-red-500 rounded-xl flex items-center justify-center text-xl shadow-lg shadow-green-900/20">
          🇧🇩
        </div>
        <div>
          <h1 className="font-bold text-lg leading-tight">Bondhu AI</h1>
          <p className="text-xs text-slate-400">Local vibes, Global brain</p>
        </div>
      </div>

      <nav className="space-y-2 flex-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setMode(item.id)}
            className={`w-full text-left p-3 rounded-xl transition-all duration-200 group flex items-start gap-3 ${
              currentMode === item.id 
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' 
              : 'hover:bg-slate-800 text-slate-400 hover:text-slate-100'
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            <div className="overflow-hidden">
              <p className="font-medium text-sm">{item.label}</p>
              <p className={`text-[10px] truncate ${currentMode === item.id ? 'text-blue-100' : 'text-slate-500'}`}>
                {item.desc}
              </p>
            </div>
          </button>
        ))}
      </nav>

      <div className="mt-auto pt-6 border-t border-slate-800 p-2">
        <div className="bg-slate-800/50 rounded-lg p-3 text-[10px] text-slate-500 italic">
          "Deshi AI, Shobar Bondhu" - Always here to help you! 🌟
        </div>
      </div>
    </div>
  );
};

export default Sidebar;

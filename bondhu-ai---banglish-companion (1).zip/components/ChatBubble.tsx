
import React from 'react';
import { Message } from '../types';

interface ChatBubbleProps {
  message: Message;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isModel = message.role === 'model';

  return (
    <div className={`flex ${isModel ? 'justify-start' : 'justify-end'} mb-4 animate-in fade-in slide-in-from-bottom-2`}>
      <div className={`max-w-[85%] md:max-w-[70%] rounded-2xl p-4 shadow-sm ${
        isModel 
          ? 'bg-slate-800 text-slate-100 rounded-bl-none' 
          : 'bg-blue-600 text-white rounded-br-none'
      }`}>
        <div className="flex items-center gap-2 mb-1">
           <span className="text-[10px] font-bold opacity-70 uppercase tracking-wider">
             {isModel ? 'Bondhu AI' : 'Apni'}
           </span>
        </div>

        {message.type === 'text' && (
          <div className="whitespace-pre-wrap leading-relaxed bengali-text">
            {message.text}
          </div>
        )}

        {message.type === 'image' && message.imageUrl && (
          <div className="space-y-3">
            <img 
              src={message.imageUrl} 
              alt="AI Generated" 
              className="rounded-lg w-full object-cover border border-slate-700 hover:scale-[1.02] transition-transform cursor-pointer"
              onClick={() => window.open(message.imageUrl, '_blank')}
            />
            <p className="text-sm opacity-90 italic bengali-text">{message.text}</p>
          </div>
        )}

        {message.groundingUrls && message.groundingUrls.length > 0 && (
          <div className="mt-3 pt-3 border-t border-slate-700/50">
            <p className="text-[10px] font-bold mb-2 uppercase opacity-60">Source theke check korun:</p>
            <div className="flex flex-wrap gap-2">
              {message.groundingUrls.map((link, idx) => (
                <a 
                  key={idx} 
                  href={link.uri} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[11px] bg-slate-900/50 px-2 py-1 rounded border border-slate-700 hover:border-blue-500 transition-colors truncate max-w-[150px]"
                >
                  🔗 {link.title}
                </a>
              ))}
            </div>
          </div>
        )}
        
        <div className={`text-[9px] mt-2 opacity-40 text-right`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    </div>
  );
};

export default ChatBubble;
